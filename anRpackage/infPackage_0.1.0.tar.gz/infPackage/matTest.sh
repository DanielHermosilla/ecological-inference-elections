#!/bin/bash

# Exit if any command fails
set -e

# Run R script inline with correct syntax
Rscript -e '
library(infPackage)

# Define matrix_1
matrix_1 <- matrix(c(
  1.0, 3.0, 5.0,
  2.0, 4.0, 6.0,
  7.0, 8.0, 9.0
), nrow = 3, byrow = TRUE)

# Compute row sums of matrix_1
row_sums_1 <- rowSums(matrix_1)

# Create a new matrix_2 where column sums match row_sums_1
n_cols_2 <- 8  # Number of columns in matrix_2
base_values <- matrix(as.double(1:(3 * n_cols_2)), nrow = 3, ncol = n_cols_2)

# Scale columns so that their sums match row_sums_1
column_sums <- colSums(base_values)
scaling_factors <- row_sums_1 / sum(column_sums) * n_cols_2
matrix_2 <- sweep(base_values, 1, scaling_factors, "*")

# Verify that row sums of matrix_1 match column sums of matrix_2
print(row_sums_1)
print(colSums(matrix_2))

# Call RsetParameters with the adjusted matrices
RsetParameters(matrix_1, matrix_2)
'

